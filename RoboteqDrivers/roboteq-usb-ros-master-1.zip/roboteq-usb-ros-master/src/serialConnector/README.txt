main.cpp is not part of ROS project. It is only uised to test/develop serialConnector.
Just run "make" or "make clean" to build it:wq

