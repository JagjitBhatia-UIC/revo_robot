Robo spriting format
Place one roboteq command per line
Insert *delay between commands (on its own line) to specify delay
between commands. 
*1000 means 1000 ms
