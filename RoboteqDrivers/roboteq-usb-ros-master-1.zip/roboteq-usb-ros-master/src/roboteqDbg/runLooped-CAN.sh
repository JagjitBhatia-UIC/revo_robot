#!/bin/bash
#./roboteqDbg -p /dev/tty.MCS78XX_Port1.1 -c -l 100 -d 1000 -f ./roboFiles/on-off-CAN.robo
./roboteqDbg -p /dev/ttyUSB0 -c -l 100 -d 1000 -f ./roboFiles/on-off-CAN.robo

