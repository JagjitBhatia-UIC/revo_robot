#!/bin/bash
#./roboteqDbg -p /dev/tty.usbmodem1411 -l 100 -d 1000 -f ./roboFiles/on-off.robo
./roboteqDbg -p /dev/ttyUSB0 -l 100 -d 1000 -f ./roboFiles/up-down.robo

