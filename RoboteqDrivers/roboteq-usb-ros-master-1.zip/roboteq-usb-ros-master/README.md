# roboteq-usb-ros
ROS driver for Roboteq Motor Controllers. Direct serial port connection can be made over usb straight to the computer.
